from distutils.core import setup

setup(name="a_san", version="2.0", description="a_san's module", author="a_san", py_modules=['suba.aa', 'suba.bb', 'subb.aa', 'subb.bb'])
