def showaa():
	print "this is aa"
